import { Component, ElementRef, ViewChild } from '@angular/core';
import { JExcelComponent } from './JExcel/jexcel.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  @ViewChild(JExcelComponent) JEXCELCOM:JExcelComponent | undefined;
  
  title = 'JExcelProject';
  Columns: Array<any> = [];
  Data: Array<any> = [];
  
  constructor(
  ) { }

  ngOnInit(): void {
    this.Columns = [
      {
        type: 'text', readOnly:true
      },
      {
        type: 'text',
      },
      {
        type: 'text',
      },
      { 
        type: 'AgDropDown'
      },
    ]

    this.Data = [];

    setTimeout(() => {
      let ColumnOnChangeObs:any = this.JEXCELCOM?.GetColumnsConfig() || [];
      console.log(this.JEXCELCOM?.GetConfig());
      ColumnOnChangeObs.AgColumns[0].AgOnChangeSubject.subscribe((response:any) => {
        console.log(response);
      })

    }, 1000);
  }

  ConsoleThis(data:any){
    console.log(data);
  }
}
